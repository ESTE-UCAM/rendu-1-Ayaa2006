
    
public class terrains{
    private int id_terrain;
    private String nom_terrain;    
    private String type;
    public void adduser(int id_terrain, String nom_terrain, String type) {
        this.id_terrain = id_terrain;
        this.type = type;
    }

    public void getId() { 
        System.out.println(id_terrain);
    }
    public void getnom() {
        System.out.println(nom_terrain);
    }
    public void gettype() {
        System.out.println(type);
    }

    public void deleteuser(int id_user){
        
        System.out.println("user supprimé");
    }
}

